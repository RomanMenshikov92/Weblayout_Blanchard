document.addEventListener('DOMContentLoaded', function () {
  // Инициализация плагина тултипов
  tippy('.js-btn-tooltip', {
    theme: 'Blanchard',
    maxWidth: 265,
  });

})
